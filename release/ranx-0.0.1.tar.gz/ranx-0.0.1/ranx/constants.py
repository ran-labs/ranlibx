from pathlib import Path


PROJECT_ROOT: str = str(Path(__file__).parent.parent)
LIB_ROOT: str = str(Path(__file__).parent)

RAN_DOMAIN: str = "ran.so"

RAN_TOKEN_FILE_NAME: str = ".ranprofile"
